from .openalgo_matcher import *

__doc__ = openalgo_matcher.__doc__
if hasattr(openalgo_matcher, "__all__"):
    __all__ = openalgo_matcher.__all__